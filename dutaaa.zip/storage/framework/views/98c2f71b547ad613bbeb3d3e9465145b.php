<h3>Keranjang Saya</h3>

<?php if($carts->isEmpty()): ?>
    <p>Keranjang kosong</p>
<?php else: ?>
    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-center mb-3">
            <?php if($cart->barang && $cart->barang->gambar): ?>
                <img src="<?php echo e(asset('storage/' . $cart->barang->gambar)); ?>" width="80">
            <?php else: ?>
                <img src="<?php echo e(asset('images/katalog/default.jpg')); ?>" width="80">
            <?php endif; ?>


            <div class="ms-3">
                <strong><?php echo e($cart->barang->nama_barang ?? 'Barang tidak tersedia'); ?>

                </strong><br>
                Qty: <?php echo e($cart->qty); ?><br>
                Harga: Rp <?php echo e(number_format($cart->barang->harga, 0, ',', '.')); ?>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/cart/index.blade.php ENDPATH**/ ?>