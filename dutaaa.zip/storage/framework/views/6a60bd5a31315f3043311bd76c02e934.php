

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Riwayat Log Stok</h2>
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="GET" class="mb-3 d-flex gap-2">
                <select name="barang_id" class="form-select">
                    <option value="">-- Semua Barang --</option>
                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($barang->id); ?>" <?php echo e(request('barang_id') == $barang->id ? 'selected' : ''); ?>>
                        <?php echo e($barang->nama_barang); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <select name="user_id" class="form-select">
                    <option value="">-- Semua User --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="<?php echo e(route('log_stoks.index')); ?>" class="btn btn-secondary">Reset</a>
            </form>

            <table class="table table-striped table-hover align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Barang</th>
                        <th>User</th>
                        <th>Jumlah Perubahan</th>
                        <th>Keterangan</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($log->id); ?></td>
                        <td><?php echo e($log->barang->nama_barang); ?></td>
                        <td><?php echo e($log->user->name); ?></td>
                        <td><?php echo e($log->jumlah_perubahan); ?></td>
                        <td><?php echo e($log->keterangan ?? '-'); ?></td>
                        <td><?php echo e($log->created_at->format('d-m-Y H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-center mt-3">
                <?php echo e($logs->withQueryString()->links('pagination::bootstrap-5')); ?>

            </div>

            <style>
                /* ✨ Biar pagination kelihatan rapi dan kecil */
                .pagination {
                    justify-content: center;
                    font-size: 0.9rem;
                }

                .pagination .page-item .page-link {
                    padding: 0.35rem 0.7rem;
                    border-radius: 8px;
                }

                .pagination .page-item.active .page-link {
                    background-color: #0d6efd;
                    border-color: #0d6efd;
                }

            </style>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\duta_auto_prima\resources\views/log_stoks/index.blade.php ENDPATH**/ ?>