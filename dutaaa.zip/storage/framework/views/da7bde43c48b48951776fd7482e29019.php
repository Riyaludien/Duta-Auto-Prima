

<?php $__env->startSection('title', 'Kategori Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Kategori Barang</h1>
    <a href="<?php echo e(route('kategoris.create')); ?>" class="btn btn-primary">+ Tambah</a>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="GET" class="mb-3 d-flex gap-2">
            <input type="text" name="nama" class="form-control" placeholder="Cari Kategori" value="<?php echo e(request('nama')); ?>">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('kategoris.index')); ?>" class="btn btn-secondary">Reset</a>
        </form>

        <table class="table table-striped table-hover align-middle">
            <thead class="table-primary">
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($kategori->nama_kategori); ?></td>
                    <td><?php echo e($kategori->deskripsi ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('kategoris.edit', $kategori->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('kategoris.destroy', $kategori->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin mau hapus kategori ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Belum ada kategori.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($kategoris->links()); ?>

    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/kategoris/index.blade.php ENDPATH**/ ?>