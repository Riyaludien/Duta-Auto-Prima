<h2>Keranjang Saya</h2>

<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        Produk ID: <?php echo e($cart->product_id); ?> <br>
        Jumlah: <?php echo e($cart->qty); ?>

        <hr>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/cart/index.blade.php ENDPATH**/ ?>