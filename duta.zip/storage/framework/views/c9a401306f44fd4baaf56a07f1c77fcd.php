

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Edit Barang</h2>

    <form action="<?php echo e(route('barangs.update', $barang->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" value="<?php echo e(old('nama_barang', $barang->nama_barang)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Kategori</label>
            <select name="kategori_id" class="form-control" required>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kategori->id); ?>" <?php echo e($barang->kategori_id == $kategori->id ? 'selected' : ''); ?>>
                        <?php echo e($kategori->nama_kategori); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Stok</label>
            <input type="number" name="stok" class="form-control" value="<?php echo e(old('stok', $barang->stok)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga" class="form-control" value="<?php echo e(old('harga', $barang->harga)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Supplier</label>
            <input type="text" name="supplier" class="form-control" value="<?php echo e(old('supplier', $barang->supplier)); ?>">
        </div>

        <button type="submit" class="btn btn-success">Update</button>
        <a href="<?php echo e(route('barangs.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/barangs/edit.blade.php ENDPATH**/ ?>