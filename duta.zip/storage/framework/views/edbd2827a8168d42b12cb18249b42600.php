

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Tambah Barang</h2>

        <form action="<?php echo e(route('barangs.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label>Nama Barang</label>
                <input type="text" name="nama_barang" class="form-control" value="<?php echo e(old('nama_barang')); ?>" required>
            </div>

            <div class="mb-3">
                <label>Kategori</label>
                <select name="kategori_id" class="form-control" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>">
                            <?php echo e($kategori->nama_kategori); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Stok</label>
                <input type="number" name="stok" class="form-control" value="0" required>
            </div>

            <div class="mb-3">
                <label>Harga</label>
                <input type="number" name="harga" class="form-control" value="0" required>
            </div>

            <div class="mb-3">
                <label>Supplier</label>
                <input type="text" name="supplier" class="form-control" value="<?php echo e(old('supplier')); ?>">
            </div>

            <div class="mb-3">
                <label>Gambar Barang</label>
                <input type="file" name="gambar" class="form-control">
            </div>

            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="<?php echo e(route('barangs.index')); ?>" class="btn btn-secondary">Batal</a>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/barangs/create.blade.php ENDPATH**/ ?>