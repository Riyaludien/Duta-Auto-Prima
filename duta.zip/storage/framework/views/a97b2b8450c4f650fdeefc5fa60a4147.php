<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Dashboard</h1>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <h5>Total Barang</h5>
                    <h2><?php echo e($totalBarang); ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <h5>Total Kategori</h5>
                    <h2><?php echo e($totalKategori); ?></h2>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mt-5 shadow-sm border-0">
        <div class="card-body">
            <h5 class="mb-4 text-center">Grafik Stok per Kategori</h5>
            <canvas id="stokChart"></canvas>
        </div>
    </div>

    
    <div class="card mt-5 shadow-sm border-0">
        <div class="card-body">
            <h5 class="mb-4 text-center">Daftar Barang Terbaru</h5>

            <table class="table table-striped table-hover align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th>Supplier</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($barang->nama_barang); ?></td>
                            <td><?php echo e($barang->kategori->nama_kategori ?? '-'); ?></td>
                            <td><?php echo e($barang->stok); ?></td>
                            <td>Rp <?php echo e(number_format($barang->harga, 0, ',', '.')); ?></td>
                            <td><?php echo e($barang->supplier ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">Belum ada data barang</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('stokChart');
        const labels = <?php echo json_encode($stokPerKategori->pluck('nama_kategori'), 15, 512) ?>;
        const data = <?php echo json_encode($stokPerKategori->pluck('barangs_sum_stok'), 15, 512) ?>;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Stok',
                    data: data,
                    borderWidth: 1,
                    backgroundColor: '#0d6efd'
                }]
            },
            options: { scales: { y: { beginAtZero: true } } }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/dashboard.blade.php ENDPATH**/ ?>