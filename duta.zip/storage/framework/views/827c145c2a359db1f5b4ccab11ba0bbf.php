

<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Daftar Transaksi</h1>
    <a href="<?php echo e(route('transaksis.create')); ?>" class="btn btn-primary">+ Tambah</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="GET" class="mb-3 row g-2 align-items-center">
            <div class="col-auto">
                <select name="user_id" class="form-select">
                    <option value="">-- Semua User --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-auto">
                <select name="status" class="form-select">
                    <option value="">-- Semua Status --</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($status)); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-auto">
                <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
            </div>

            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="<?php echo e(route('transaksis.index')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </form>

        <table class="table table-striped table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaksi->id); ?></td>
                    <td><?php echo e($transaksi->user->name); ?></td>
                    <td>Rp <?php echo e(number_format($transaksi->total_harga, 0, ',', '.')); ?></td>
                    <td><?php echo e(ucfirst($transaksi->status)); ?></td>
                    <td><?php echo e($transaksi->created_at->format('d-m-Y H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('transaksis.show', $transaksi->id)); ?>" class="btn btn-sm btn-info">Detail</a>
                        <a href="<?php echo e(route('transaksis.edit', $transaksi->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                        
                        <form action="<?php echo e(route('transaksis.destroy', $transaksi->id)); ?>" method="POST" class="d-inline delete-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn btn-sm btn-danger btn-delete">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">Belum ada transaksi</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($transaksis->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const deleteButtons = document.querySelectorAll(".btn-delete");

        deleteButtons.forEach(button => {
            button.addEventListener("click", function(e) {
                const form = this.closest("form");

                Swal.fire({
                    title: "Yakin hapus transaksi?"
                    , text: "Data yang dihapus tidak dapat dikembalikan!"
                    , icon: "warning"
                    , showCancelButton: true
                    , confirmButtonColor: "#d33"
                    , cancelButtonColor: "#3085d6"
                    , confirmButtonText: "Ya, hapus!"
                    , cancelButtonText: "Batal"
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\duta_auto_prima\resources\views/transaksis/index.blade.php ENDPATH**/ ?>