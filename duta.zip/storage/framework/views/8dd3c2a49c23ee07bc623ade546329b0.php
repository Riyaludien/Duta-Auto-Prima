 

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Daftar Pesanan Masuk</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Transaksi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tgl</th>
                            <th>Pelanggan</th>
                            <th>Layanan</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->booking_date); ?></td>
                            <td>
                                <strong><?php echo e($item->customer_name); ?></strong><br>
                                <small><?php echo e($item->customer_phone); ?></small>
                            </td>
                            <td><?php echo e($item->item_name); ?></td>
                            <td><?php echo e($item->item_price); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($item->status == 'Selesai' ? 'success' : ($item->status == 'Proses' ? 'primary' : 'warning')); ?>">
                                    <?php echo e($item->status); ?>

                                </span>
                            </td>
                            <td>
                                
                                <form action="<?php echo e(route('admin.bookings.update', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group input-group-sm">
                                        <select name="status" class="form-select form-control">
                                            <option value="Menunggu" <?php echo e($item->status == 'Menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                                            <option value="Proses" <?php echo e($item->status == 'Proses' ? 'selected' : ''); ?>>Proses</option>
                                            <option value="Selesai" <?php echo e($item->status == 'Selesai' ? 'selected' : ''); ?>>Selesai</option>
                                            <option value="Batal" <?php echo e($item->status == 'Batal' ? 'selected' : ''); ?>>Batal</option>
                                        </select>
                                        <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i></button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\duta_auto_prima\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>