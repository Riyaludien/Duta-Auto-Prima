

<?php $__env->startSection('title', 'Daftar Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Daftar Barang</h1>
    <a href="<?php echo e(route('barangs.create')); ?>" class="btn btn-primary">+ Tambah</a>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="GET" class="mb-3 d-flex gap-2">
            <select name="kategori_id" class="form-select">
                <option value="">-- Semua Kategori --</option>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('kategori_id') == $kategori->id ? 'selected' : ''); ?>>
                    <?php echo e($kategori->nama_kategori); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="text" name="supplier" class="form-control" placeholder="Supplier" value="<?php echo e(request('supplier')); ?>">

            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('barangs.index')); ?>" class="btn btn-secondary">Reset</a>
        </form>

        <table class="table table-striped table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga</th>
                    <th>Supplier</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($barang->nama_barang); ?></td>
                    <td><?php echo e($barang->kategori->nama_kategori ?? '-'); ?></td>
                    <td><?php echo e($barang->stok); ?></td>
                    <td>Rp <?php echo e(number_format($barang->harga, 0, ',', '.')); ?></td>
                    <td><?php echo e($barang->supplier ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('barangs.edit', $barang->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('barangs.destroy', $barang->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin mau hapus barang ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">Belum ada data barang</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($barangs->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Riyaludin\AMIKOM\duta_auto_prima\resources\views/barangs/index.blade.php ENDPATH**/ ?>