<h2>Keranjang Saya</h2>

@foreach ($carts as $cart)
    <div>
        Produk ID: {{ $cart->product_id }} <br>
        Jumlah: {{ $cart->qty }}
        <hr>
    </div>
@endforeach